# 10_count_zeros_matrix.py
r, c = map(int, input('Enter rows and columns: ').split())
matrix = [list(map(int, input().split())) for _ in range(r)]
zero_count = sum(row.count(0) for row in matrix)
print('Number of zeros in matrix:', zero_count)
