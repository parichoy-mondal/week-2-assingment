# 8_dynamic_array.py
arr = []
while True:
    print('\n1. Insert\n2. Delete\n3. Display\n4. Exit')
    choice = int(input('Enter choice: '))
    if choice == 1:
        val = int(input('Enter value: '))
        arr.append(val)
    elif choice == 2:
        val = int(input('Enter value to delete: '))
        if val in arr:
            arr.remove(val)
        else:
            print('Value not found')
    elif choice == 3:
        print('Array:', arr)
    elif choice == 4:
        break
    else:
        print('Invalid choice')
