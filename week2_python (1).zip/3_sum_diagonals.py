# 3_sum_diagonals.py
n = int(input('Enter matrix size (n x n): '))
matrix = [list(map(int, input().split())) for _ in range(n)]
primary = sum(matrix[i][i] for i in range(n))
secondary = sum(matrix[i][n-i-1] for i in range(n))
print('Sum of primary diagonal:', primary)
print('Sum of secondary diagonal:', secondary)
