# 9_identity_matrix.py
n = int(input('Enter matrix size (n x n): '))
matrix = [list(map(int, input().split())) for _ in range(n)]
is_identity = True
for i in range(n):
    for j in range(n):
        if (i == j and matrix[i][j] != 1) or (i != j and matrix[i][j] != 0):
            is_identity = False
            break
if is_identity:
    print('Identity Matrix')
else:
    print('Not Identity Matrix')
