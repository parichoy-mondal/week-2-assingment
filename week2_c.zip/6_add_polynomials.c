/* 6_add_polynomials.c */
#include <stdio.h>
int main() {
    int n; scanf("%d",&n);
    int a[n+1], b[n+1], res[n+1];
    for(int i=0;i<=n;i++) scanf("%d",&a[i]);
    for(int i=0;i<=n;i++) scanf("%d",&b[i]);
    for(int i=0;i<=n;i++) res[i]=a[i]+b[i];
    for(int i=0;i<=n;i++) printf("%d ", res[i]);
    printf("\n");
    return 0;
}
