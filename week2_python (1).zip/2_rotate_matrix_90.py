# 2_rotate_matrix_90.py
n = int(input('Enter matrix size (n x n): '))
matrix = [list(map(int, input().split())) for _ in range(n)]
rotated = list(zip(*matrix[::-1]))
print('Matrix after 90 degree rotation:')
for row in rotated:
    print(*row)
