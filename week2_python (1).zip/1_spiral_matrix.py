def spiralOrder(matrix):
    result = []
    top, bottom = 0, len(matrix)-1
    left, right = 0, len(matrix[0])-1
    while top <= bottom and left <= right:
        for j in range(left, right+1):
            result.append(matrix[top][j])
        top += 1
       for i in range(top, bottom+1):
            result.append(matrix[i][right])
        right -= 1
        if top <= bottom:
            for j in range(right, left-1, -1):
                result.append(matrix[bottom][j])
            bottom -= 1
        if left <= right:
            for i in range(bottom, top-1, -1):
                result.append(matrix[i][left])
            left += 1
    return result

if __name__ == '__main__':
    r, c = map(int, input('Enter rows and columns: ').split())
    matrix = [list(map(int, input().split())) for _ in range(r)]
    print('Spiral order:', *spiralOrder(matrix))
