# 7_multiply_polynomials.py
n = int(input('Enter degree of first polynomial: '))
m = int(input('Enter degree of second polynomial: '))
print('Enter', n+1, 'coefficients for first polynomial (a0 .. an):')
poly1 = list(map(int, input().split()))
print('Enter', m+1, 'coefficients for second polynomial (b0 .. bm):')
poly2 = list(map(int, input().split()))
result = [0] * (n + m + 1)
for i in range(n+1):
    for j in range(m+1):
        result[i+j] += poly1[i] * poly2[j]
print('Product of polynomials coefficients:', result)
