# 4_transpose_matrix.py
r, c = map(int, input('Enter rows and columns: ').split())
matrix = [list(map(int, input().split())) for _ in range(r)]
transpose = list(zip(*matrix))
print('Transpose of matrix:')
for row in transpose:
    print(*row)
