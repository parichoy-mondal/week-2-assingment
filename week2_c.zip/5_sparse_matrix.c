/* 5_sparse_matrix.c */
#include <stdio.h>
int main() {
    int r,c; scanf("%d %d",&r,&c);
    int a[r][c];
    int zeros=0;
    for(int i=0;i<r;i++) for(int j=0;j<c;j++) { scanf("%d",&a[i][j]); if(a[i][j]==0) zeros++; }
    if(zeros > (r*c)/2) printf("Sparse Matrix\n"); else printf("Not a Sparse Matrix\n");
    return 0;
}
