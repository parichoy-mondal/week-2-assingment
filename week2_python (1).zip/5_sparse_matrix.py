# 5_sparse_matrix.py
r, c = map(int, input('Enter rows and columns: ').split())
matrix = [list(map(int, input().split())) for _ in range(r)]
zero_count = sum(row.count(0) for row in matrix)
if zero_count > (r * c) // 2:
    print('Sparse Matrix')
else:
    print('Not a Sparse Matrix')
