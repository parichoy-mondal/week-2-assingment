/* 8_dynamic_array.c */
#include <stdio.h>
#include <stdlib.h>
int main() {
    int *arr = NULL, n = 0, choice, val, i, found;
    while(1) {
        printf("\n1.Insert 2.Delete 3.Display 4.Exit\n");
        if(scanf("%d", &choice)!=1) break;
        if(choice==1) {
            scanf("%d", &val);
            arr = realloc(arr, (n+1)*sizeof(int));
            arr[n++] = val;
        } else if(choice==2) {
            scanf("%d", &val);
            found=0;
            for(i=0;i<n;i++) if(arr[i]==val){ found=1; for(int j=i;j<n-1;j++) arr[j]=arr[j+1]; n--; arr=realloc(arr,n*sizeof(int)); break; }
            if(!found) printf("Value not found\n");
        } else if(choice==3) {
            for(i=0;i<n;i++) printf("%d ", arr[i]);
            printf("\n");
        } else break;
    }
    free(arr);
    return 0;
}
