n = int(input('Enter highest degree of polynomial: '))
print('Enter', n+1, 'coefficients for first polynomial (a0 a1 ... an):')
poly1 = list(map(int, input().split()))
print('Enter', n+1, 'coefficients for second polynomial (a0 a1 ... an):')
poly2 = list(map(int, input().split()))
result = [poly1[i] + poly2[i] for i in range(n+1)]
print('Sum of polynomials coefficients:', result)
