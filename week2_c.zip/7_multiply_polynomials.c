/* 7_multiply_polynomials.c */
#include <stdio.h>
#include <string.h>
int main() {
    int n,m; scanf("%d %d", &n, &m);
    int a[n+1], b[m+1];
    for(int i=0;i<=n;i++) scanf("%d", &a[i]);
    for(int j=0;j<=m;j++) scanf("%d", &b[j]);
    int res[n+m+1]; memset(res,0,sizeof(res));
    for(int i=0;i<=n;i++) for(int j=0;j<=m;j++) res[i+j]+=a[i]*b[j];
    for(int k=0;k<=n+m;k++) printf("%d ", res[k]);
    printf("\n");
    return 0;
}
